#include <stdio.h>
#include <vector>
#include <boost/optional.hpp>
#include <wx/window.h>
#include "local.h"
